namespace LiceoArchivos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btncrear_Click(object sender, EventArgs e)
        {
            string texto = txtnombre.Text;
            string ruta = @"C:\Users\Ana Mercedes V�squez\Documents\" + texto + ".txt";
            using (StreamWriter sw = new StreamWriter(ruta)) {
                sw.WriteLine(txtcomentario.Text);

            
            
           }
            MessageBox.Show("se creo correctamente");

        }

        private void txtcomentario_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}