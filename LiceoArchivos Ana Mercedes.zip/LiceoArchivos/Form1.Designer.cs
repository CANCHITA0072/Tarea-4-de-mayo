﻿namespace LiceoArchivos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txtcomentario = new System.Windows.Forms.TextBox();
            this.txtlectura = new System.Windows.Forms.TextBox();
            this.btncrear = new System.Windows.Forms.Button();
            this.btnlectura = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(45, 44);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(133, 23);
            this.txtnombre.TabIndex = 0;
            // 
            // txtcomentario
            // 
            this.txtcomentario.Location = new System.Drawing.Point(223, 79);
            this.txtcomentario.Multiline = true;
            this.txtcomentario.Name = "txtcomentario";
            this.txtcomentario.Size = new System.Drawing.Size(236, 103);
            this.txtcomentario.TabIndex = 1;
            this.txtcomentario.TextChanged += new System.EventHandler(this.txtcomentario_TextChanged);
            // 
            // txtlectura
            // 
            this.txtlectura.Location = new System.Drawing.Point(485, 44);
            this.txtlectura.Name = "txtlectura";
            this.txtlectura.Size = new System.Drawing.Size(133, 23);
            this.txtlectura.TabIndex = 2;
            // 
            // btncrear
            // 
            this.btncrear.Location = new System.Drawing.Point(60, 150);
            this.btncrear.Name = "btncrear";
            this.btncrear.Size = new System.Drawing.Size(75, 23);
            this.btncrear.TabIndex = 3;
            this.btncrear.Text = "Crear";
            this.btncrear.UseVisualStyleBackColor = true;
            this.btncrear.Click += new System.EventHandler(this.btncrear_Click);
            // 
            // btnlectura
            // 
            this.btnlectura.Location = new System.Drawing.Point(517, 150);
            this.btnlectura.Name = "btnlectura";
            this.btnlectura.Size = new System.Drawing.Size(75, 23);
            this.btnlectura.TabIndex = 4;
            this.btnlectura.Text = "Lectura";
            this.btnlectura.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnlectura);
            this.Controls.Add(this.btncrear);
            this.Controls.Add(this.txtlectura);
            this.Controls.Add(this.txtcomentario);
            this.Controls.Add(this.txtnombre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtnombre;
        private TextBox txtcomentario;
        private TextBox txtlectura;
        private Button btncrear;
        private Button btnlectura;
    }
}